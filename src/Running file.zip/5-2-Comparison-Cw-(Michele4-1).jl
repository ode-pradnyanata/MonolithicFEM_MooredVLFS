include("1-2-research-mooring-michele (4-1).jl")

import .Mooring_Case: Mooring_case_params, run_mooring_case_freq_domain, collect_results, run_Mooring

using Plots
using Parameters
using DrWatson
using JLD2
using DataFrames
using CSV
using Roots
using LaTeXStrings

# -------------------------------------------------------------
#   1  REFERENCES DATA  ---------------------------------------
# -------------------------------------------------------------

# -------------------------------------------------------------
#   2  FUNCTIONS  ---------------------------------------------
# -------------------------------------------------------------
# Func 1 ------------------------------------------------------
function Producing_Output(range_vpto, path_case, wave_number, wave_freq, mesh_size, damping_length_coeff, beam_length)
wave_number = wave_number
wave_freq = wave_freq
range_vpto = range_vpto
nRange_vpto = length(range_vpto)
nWave = length(wave_number)
comp_time = zeros(nRange_vpto, nWave)
for j = 1:nWave
  # ks = range_s[i]
  for i = 1:nRange_vpto
    ω_tmp = wave_freq[j]
    k_tmp = wave_number[j]
    comp_time[i,j] = @elapsed begin  
    case = Mooring_case_params(name="Michele-vpto$i-ω$j", v_pto=range_vpto[i], k_opt=k_tmp, ω_opt=ω_tmp,vtk_output=false, 
                                  h=mesh_size, cλ=damping_length_coeff, Lb=beam_length, ε=1e32, J=0)
    data, file = produce_or_load(path_case,case,run_Mooring;digits=8)
    end
    @show comp_time[i,j]
  end
end
return comp_time
end


# -------------------------------------------------------------
#   3  RUN CASE  ----------------------------------------------
# -------------------------------------------------------------
# -------------------------------------------------------------
# Wave Properties
function solve_dispersion(ω, g, h₀)
    f(k) = ω^2 - g * k * tanh(k * h₀)
    k_initial = ω^2 / g       # Initial guess for k - Deep water approximation plus small offset
    k_solution = find_zero(f, k_initial, Order2())
    return k_solution
end
g = 9.81
h₀ = 10

v_pto = 10 .^ range(2, 7, length=50)  # logscale
n_vpto = length(v_pto)

path=datadir("5-2-Comparison-Cw-Michele")

ω_data = collect(0.2: 0.05 : 6) 
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data]
L_data = 2*π ./ k_data
@show L_data

time_init = @elapsed begin
case =  Mooring_case_params(
  name="Warm-up - Michele",
  h=1, # mesh size
  Lb=20,
  order=2,k_opt=k_data[35], ω_opt=ω_data[35], vtk_output=false, 
  cλ=2, v_pto = v_pto[8], ks=0, ks2=0, ε=1e32, J=0)
produce_or_load(path,case,run_Mooring;digits=8)
end
# 345.15 sec ~ 5.75 min

# Partial running (it can be combined for the same cλ, if required)
# batch 1
ω_data = collect(0.20: 0.05 : 0.20) 
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data]
res_20m_1 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 6, 20)
res_10m_1 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 6, 10)  

ω_data = collect(0.25: 0.05 : 0.50) 
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data] 
res_20m_1b = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 6, 20) 
res_10m_1b = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 6, 10) 

ω_data = collect(0.55: 0.05 : 1.00) 
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data] 
res_20m_1c = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 6, 20) 
res_10m_1c = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 6, 10) 

# batch 2
ω_data = collect(1.05: 0.05 : 2.00) 
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data]
res_20m_2 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 4, 20) 
res_10m_2 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 4, 10) 

ω_data = collect(2.05: 0.05 : 3.00)  
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data] 
res_20m_2b = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 4, 20)  
res_10m_2b = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 4, 10)  

# batch 3
ω_data = collect(3.05: 0.05 : 4.00)   
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data] 
res_20m_3 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 2, 20) 
res_10m_3 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 2, 10)

ω_data = collect(4.05: 0.05 : 5.00)
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data] 
res_20m_4 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 2, 20)
res_10m_4 = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 2, 10) 

ω_data = collect(5.05: 0.05 : 6.00)  
k_data = [solve_dispersion(ω, g, h₀) for ω in ω_data] 
res_20m_4b = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 2, 20)  
res_10m_4b = Producing_Output(v_pto, path, k_data, ω_data, 0.2, 2, 10) 

# 1) 56 x 50  L=20m - 2.27hr
# 2) 117 x 50 L=10m - 8.69hr
#    ω = 0.20 - 1.00, cλ = 6
#    ω = 1.05 - 3.00, cλ = 4
#    ω = 3.05 - 6.00, cλ = 2
# 3) 117 x 50 L=20m - 7.57hr
#    ω = 0.20 - 1.50, cλ = 4
#    ω = 1.55 - 6.00, cλ = 2
# 4) 117 x 50 L=20m - 5.59hr
#    ω = 0.20 - 1.50, cλ = 2
#    ω = 1.55 - 6.00, cλ = 2
# 5) 117 x 50 L=20m - 12.5hr
#    ω = 0.20 - 1.00, cλ = 6
#    ω = 1.05 - 3.00, cλ = 4
#    ω = 3.05 - 6.00, cλ = 2
# 6) 117 x 50 L=20m - hr
#    re run for \\ sign
#    1747.88 + 4504.95 +2997.89 + 2810.74 + \\11.76 + \\1355.53 + 2503.10
# 7) 117 x 50 L=10m - hr
#    re run for \\ sign
#    1359.17 + 4645.93 + 3436.33 + 1895.38 + \\21.02 + \\31.32 + 1550.32

total_20m=sum(res_20m_1)+sum(res_20m_1b)+sum(res_20m_2)+sum(res_20m_2b)+sum(res_20m_3)+sum(res_20m_4)+sum(res_20m_4b)
total_10m=sum(res_10m_1)+sum(res_10m_1b)+sum(res_10m_2)+sum(res_10m_2b)+sum(res_10m_3)+sum(res_10m_4)+sum(res_10m_4b)
total_20_hr=total_20m/60/60
total_10_hr=total_10m/60/60

# Collect data 
result = collect_results(path)
df = DataFrame(result)

# Collecting Output
ω_data = collect(0.2: 0.05 : 6)
n_wavedata = length(ω_data)
result_Cw_10 = zeros(n_vpto,n_wavedata) # row - col
result_Cw_20 = zeros(n_vpto,n_wavedata) # row - col
for i = 1:n_vpto
  for j = 1:n_wavedata
    result_data_20 = filter(row -> row.v_pto == round(v_pto[i], digits=8) && row.ω_opt == round(ω_data[j],digits=8) && row.Lb == 20, df)
    result_Cw_20[i,j] = result_data_20.Cw[1]

    result_data_10 = filter(row -> row.v_pto == round(v_pto[i], digits=8) && row.ω_opt == round(ω_data[j],digits=8) && row.Lb == 10, df)
    result_Cw_10[i,j] = result_data_10.Cw[1]
  end
end

# Plots
default(
  tickfontsize=13,
  legendfontsize=13,
  labelfontsize=16,
  titlefontsize=16)
plt_10= heatmap(
    ω_data,
    (v_pto),
    result_Cw_10;
    yscale = :log10,
    yticks = (10 .^ (2:7), ["10²","10³","10⁴","10⁵","10⁶","10⁷"]),
    levels = 30,
    color = :turbo,
    clims = (0.0, 1.0),
    xlabel = L"\omega\;(\mathrm{rad\ s^{-1}})",
    ylabel = L"\nu_{PTO}\;(\mathrm{kg\ m^{-1}\ s^{-1}})",
    colorbar_title = L"C_w",
    colorbar_titlefontsize = 16,   
    title=L"\textbf{Capture-Width \: Ratio \: (C_w)} , Lb = 10m",
    size = (700,600),
    framestyle = :box,
)
savefig(plt_10, plotsdir("5-2-Comparison-Cw","Cw-heatmap-10m"))

# contourf(
plt_20= heatmap(
    ω_data,
    (v_pto),
    result_Cw_20;
    yscale = :log10,
    yticks = (10 .^ (2:7), ["10²","10³","10⁴","10⁵","10⁶","10⁷"]),
    levels = 30,
    color = :turbo,
    clims = (0.0, 1.0),
    xlabel = L"\omega\;(\mathrm{rad\ s^{-1}})",
    ylabel = L"\nu_{PTO}\;(\mathrm{kg\ m^{-1}\ s^{-1}})",
    colorbar_title = L"C_w",
    colorbar_titlefontsize = 16,  
    title=L"\textbf{Capture-Width \: Ratio \: (C_w)} , Lb = 20m",
    size = (700,600),
    framestyle = :box,
)
savefig(plt_20, plotsdir("5-2-Comparison-Cw","Cw-heatmap-20m"))



# Manual check
# PTO Locations
# h = 0.1           # Mesh size
# Lb  = 20
# η₀ = 1
# ρ = 1000
# H = 10            # water depth
# nSegments = 6
# segment_length = Lb / nSegments

# xb₀ = 0
# xb₁ = Lb
# xbⱼ₁ = round(xb₀ + segment_length, digits = 1, base = Int(1/h))
# xbⱼ₂ = round(xb₀ + 2*segment_length, digits = 1, base = Int(1/h))
# xbⱼ₃ = round(xb₀ + 3*segment_length, digits = 1, base = Int(1/h))
# xbⱼ₄ = round(xb₀ + 4*segment_length, digits = 1, base = Int(1/h))
# xbⱼ₅ = round(xb₀ + 5*segment_length, digits = 1, base = Int(1/h))

# ω_check = 5
# v_pto_check = 1e3
# idx_v_pto = argmin(abs.(v_pto .- v_pto_check))
# idx_wave = argmin(abs.(ω_data .- ω_check))
# ω_data[idx_wave]
# v_pto[idx_v_pto]
# k_check = k_data[idx_wave]
# Cg = (ω_check/(2*k_check)) * (1+ (2*k_check*H)/(sinh(2*k_check*H)))

# result_data = filter(row -> row.v_pto == round(v_pto[idx_v_pto], digits=8) && row.ω_opt == round(ω_data[idx_wave],digits=8), df_20m)
# xs = result_data.x[1]
# ηs = result_data.η[1]
# Cws= result_data.Cw[1]
# ωs = result_data.ω[1]
# vptos = result_data.v_pto[1]

# idx_pto_loc = [argmin(abs.(xs .- xb₀)), argmin(abs.(xs .- xbⱼ₁)), argmin(abs.(xs .- xbⱼ₂)),
#            argmin(abs.(xs .- xbⱼ₃)),argmin(abs.(xs .- xbⱼ₄)),argmin(abs.(xs .- xbⱼ₅)),
#            argmin(abs.(xs .- xb₁))]
# η_pto = ηs[idx_pto_loc] .* η₀

# P_pto = (0.5 * v_pto[idx_v_pto] * ω_data[idx_wave]^2) .* η_pto.^2
# Pw = 0.5 * ρ *g * η₀^2 * Cg
# Cw = sum(P_pto)/Pw


# time_init = @elapsed begin
# case =  Mooring_case_params(
#   name="Warm-up - Michele",
#   h=0.1, # mesh size
#   Lb=20,
#   order=4,k_opt=k_data[46], ω_opt=ω_data[46], vtk_output=false, cλ=2, v_pto = v_pto[11], ks=0, ks2=0)
# res1 = produce_or_load(path,case,run_Mooring;digits=8)
# end
