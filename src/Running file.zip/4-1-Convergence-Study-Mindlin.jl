include("1-2-research-mooring-zhao.jl")

import .Mooring_Case: Mooring_case_params, run_mooring_case_freq_domain, collect_results, run_Mooring

using Plots
using Parameters
using DrWatson
using JLD2
using DataFrames
using CSV
using Printf

# -------------------------------------------------------------
#   1  RUN CASE  ----------------------------------------------
# -------------------------------------------------------------
beam_length = 10
k_data = [0.8044 2.2216 9.0434 ]                            # [C. Zhao] - dimensionless wave number = k[1/m] * H [m]
T_data = [2.8750 1.4290 0.7000 ]   
ω_data = 2π ./ T_data

hp_data = [0.038, 0.075, 0.100]                             # [C. Zhao] plate thickness
mesh_size_var = [5.00, 2.00, 1.00, 0.50, 0.20, 0.10, 0.05, 0.01] 
n_hp_data = length(hp_data)
n_mesh_size = length(mesh_size_var)
n_freq = length(ω_data)
path=datadir("4-1-Convergence-Study-Mindlin")

# Warm-up case
time_init = @elapsed begin
case =  Mooring_case_params(
  name="Warm-up",
  h=2, # mesh size
  order=2,k_opt=k_data[3], ω_opt=ω_data[3], ks=0, cλ=2, Lb=10)
produce_or_load(path,case,run_Mooring;digits=8)
end
# warmup 352.16 seconds ~ 6-7 minutes 

# Run cases - Mindlin Timoshenko beam (Producing solutions)
comp_time_Mindlin = zeros(n_hp_data, n_freq)
for i in 1:n_hp_data  
  for j in 1: n_freq
    comp_time_Mindlin[i,j] = @elapsed begin
    for k in 1:n_mesh_size
      case = Mooring_case_params(name="Mindlin-$i-$j-$k", hₚ=hp_data[i], ks=0, k_opt=k_data[j], 
                                  ω_opt=ω_data[j], h=mesh_size_var[k], vtk_output=false, cλ=4,
                                  Lb=beam_length)
      data, file = produce_or_load(path,case,run_Mooring;digits=8)
    end
    end
    @show comp_time_Mindlin[i,j]
  end
end

# ---------------------------------------------------------
# Run cases - Recovered EB beam (Producing solutions)
# Run this for checking the convergence of EB beam

# comp_time_EB = zeros(n_hp_data, n_freq)
# for i in 1:n_hp_data  
#   for j in 1: n_freq
#     comp_time_EB[i,j] = @elapsed begin    
#     for k in 1:n_mesh_size
#       case = Mooring_case_params(name="EB-$i-$j-$k", hₚ=hp_data[i], ks=0, k_opt=k_data[j], 
#                               ω_opt=ω_data[j], h=mesh_size_var[k], vtk_output=false, cλ=4, 
#                               Lb=beam_length, ε=1e32, J=0) 
#       data, file = produce_or_load(path,case,run_Mooring;digits=8)
#     end
#     end
#     @show comp_time_EB[i,j]
#   end
# end
# ---------------------------------------------------------


# -------------------------------------------------------------
#   2  OUTPUT DATA COLLECTION  --------------------------------
# -------------------------------------------------------------
result = collect_results(path)
df = DataFrame(result)

# Data bin
conv_38mm_Mindlin  = zeros(n_mesh_size, n_freq*2)
conv_75mm_Mindlin  = zeros(n_mesh_size, n_freq*2)
conv_100mm_Mindlin = zeros(n_mesh_size, n_freq*2)
# conv_38mm_EB  = zeros(n_mesh_size, n_freq*2)
# conv_75mm_EB  = zeros(n_mesh_size, n_freq*2)
# conv_100mm_EB = zeros(n_mesh_size, n_freq*2)

# Function to extract results
function extract_conv_results(res)
  x1 = 0.00       # location of interest, at the left BC (x1) and mid-span (x2)
  x2 = beam_length/2

  idx_x1 = argmin(abs.(x1 .- res.x[1]))
  idx_x2 = argmin(abs.(x2 .- res.x[1]))
  η1 = res.η[1][idx_x1]
  η2 = res.η[1][idx_x2]
  return η1, η2
end

# Mindlin results
for  i in 1:n_freq
  for j in 1:n_mesh_size
    res = filter(row -> row.name == "Mindlin-1-$i-$j" && row.Lb == beam_length, df);
    η1, η2 = extract_conv_results(res)
    conv_38mm_Mindlin[j,2*i-1] = η1; conv_38mm_Mindlin[j,2*i] = η2

    res = filter(row -> row.name == "Mindlin-2-$i-$j" && row.Lb == beam_length, df);
    η1, η2 = extract_conv_results(res)
    conv_75mm_Mindlin[j,2*i-1] = η1; conv_75mm_Mindlin[j,2*i] = η2

    res = filter(row -> row.name == "Mindlin-3-$i-$j" && row.Lb == beam_length, df);
    η1, η2 = extract_conv_results(res)
    conv_100mm_Mindlin[j,2*i-1] = η1; conv_100mm_Mindlin[j,2*i] = η2
  end
end

x1_ω1_left_Mindlin = conv_38mm_Mindlin[:,1]; x1_ω1_mid_Mindlin = conv_38mm_Mindlin[:,2]
x1_ω2_left_Mindlin = conv_38mm_Mindlin[:,3]; x1_ω2_mid_Mindlin = conv_38mm_Mindlin[:,4]
x1_ω3_left_Mindlin = conv_38mm_Mindlin[:,5]; x1_ω3_mid_Mindlin = conv_38mm_Mindlin[:,6]
x2_ω1_left_Mindlin = conv_75mm_Mindlin[:,1]; x2_ω1_mid_Mindlin = conv_75mm_Mindlin[:,2]
x2_ω2_left_Mindlin = conv_75mm_Mindlin[:,3]; x2_ω2_mid_Mindlin = conv_75mm_Mindlin[:,4]
x2_ω3_left_Mindlin = conv_75mm_Mindlin[:,5]; x2_ω3_mid_Mindlin = conv_75mm_Mindlin[:,6]
x3_ω1_left_Mindlin = conv_100mm_Mindlin[:,1]; x3_ω1_mid_Mindlin = conv_100mm_Mindlin[:,2]
x3_ω2_left_Mindlin = conv_100mm_Mindlin[:,3]; x3_ω2_mid_Mindlin = conv_100mm_Mindlin[:,4]
x3_ω3_left_Mindlin = conv_100mm_Mindlin[:,5]; x3_ω3_mid_Mindlin = conv_100mm_Mindlin[:,6]

# ---------------------------------------------------------
# Run this for extracting the EB beam output

# EB results
# for  i in 1:n_freq
#   for j in 1:n_mesh_size
#     res = filter(row -> row.name == "EB-1-$i-$j" && row.Lb == beam_length, df);
#     η1, η2 = extract_conv_results(res)
#     conv_38mm_EB[j,2*i-1] = η1; conv_38mm_EB[j,2*i] = η2

#     res = filter(row -> row.name == "EB-2-$i-$j" && row.Lb == beam_length, df);
#     η1, η2 = extract_conv_results(res)
#     conv_75mm_EB[j,2*i-1] = η1; conv_75mm_EB[j,2*i] = η2

#     res = filter(row -> row.name == "EB-3-$i-$j" && row.Lb == beam_length, df);
#     η1, η2 = extract_conv_results(res)
#     conv_100mm_EB[j,2*i-1] = η1; conv_100mm_EB[j,2*i] = η2
#   end
# end
# x1_ω1_left_EB = conv_38mm_EB[:,1]; x1_ω1_mid_EB = conv_38mm_EB[:,2] 
# x1_ω2_left_EB = conv_38mm_EB[:,3]; x1_ω2_mid_EB = conv_38mm_EB[:,4]
# x1_ω3_left_EB = conv_38mm_EB[:,5]; x1_ω3_mid_EB = conv_38mm_EB[:,6]
# x2_ω1_left_EB = conv_75mm_EB[:,1]; x2_ω1_mid_EB = conv_75mm_EB[:,2]
# x2_ω2_left_EB = conv_75mm_EB[:,3]; x2_ω2_mid_EB = conv_75mm_EB[:,4]
# x2_ω3_left_EB = conv_75mm_EB[:,5]; x2_ω3_mid_EB = conv_75mm_EB[:,6]
# x3_ω1_left_EB = conv_100mm_EB[:,1]; x3_ω1_mid_EB = conv_100mm_EB[:,2]
# x3_ω2_left_EB = conv_100mm_EB[:,3]; x3_ω2_mid_EB = conv_100mm_EB[:,4]
# x3_ω3_left_EB = conv_100mm_EB[:,5]; x3_ω3_mid_EB = conv_100mm_EB[:,6]
# ---------------------------------------------------------


# -------------------------------------------------------------
#   3 PLOTTING  -----------------------------------------------
# -------------------------------------------------------------
function plotting(y1_low, y2_high, fig_title)
  default(
    tickfontsize=13,
    legendfontsize=13,
    labelfontsize=16,
    titlefontsize=16)

  p = plot(1:length(mesh_size_var), y1_low, 
    label="ω = $(@sprintf("%.4g", ω_data[1])) rad/sec", 
    legend=(0.55, 0.35),    
    marker=:o, color=:blue,
    xticks=(1:length(mesh_size_var), mesh_size_var),
    ylabel="|η|/κ₀",
    xlabel="Characteristic mesh size, h",
    # size=(700, 600),
    yforeground_color_text=:blue,
    yforeground_color_border=:blue)
  plot!(p, grid=true, gridlinewidth=1, gridalpha=0.2)
  p1 = twinx(p)
  plot!(p1, 1:length(mesh_size_var), y2_high, 
    label="ω = $(@sprintf("%.4g", ω_data[3])) rad/sec",
    legend=(0.55, 0.50),    
    marker=:o,color=:green,
    yforeground_color_text=:green,
    yforeground_color_border=:green)
  vline!(p, [5], color=:black, linestyle=:dash, linewidth=1.5, label=false)
  display(p)
  savefig(p, plotsdir("4-1-Convergence-Study",fig_title))
end

plotting(x1_ω1_left_Mindlin, x1_ω3_left_Mindlin, "4-1 - 38mm - Left BC - Mindlin")
plotting(x2_ω1_left_Mindlin, x2_ω3_left_Mindlin, "4-1 - 75mm - Left BC - Mindlin")
plotting(x3_ω1_left_Mindlin, x3_ω3_left_Mindlin, "4-1 - 100mm - Left BC - Mindlin")

plotting(x1_ω1_mid_Mindlin, x1_ω3_mid_Mindlin, "4-1 - 38mm - Mid BC - Mindlin")
plotting(x2_ω1_mid_Mindlin, x2_ω3_mid_Mindlin, "4-1 - 75mm - Mid BC - Mindlin")
plotting(x3_ω1_mid_Mindlin, x3_ω3_mid_Mindlin, "4-1 - 100mm - Mid BC - Mindlin")
